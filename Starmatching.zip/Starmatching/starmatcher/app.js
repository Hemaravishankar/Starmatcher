const express = require('express');
const {sequelize,Company,KeyContact, user} = require('./models');
const upload = require('../starmatcher/config/multer.config')
// const bcrypt = require('bcrypt');
// const jwt = require('jsonwebtoken');

const app = express();
app.use(express.json())

app.post('/company', upload.single("CompanyImage"), async(req, res) => {
    const {companyname,shortintroduction,type,size,contacts} = req.body
    const {imageType,imageName,imageData} = req.file

    try{
        const comId = await Company.create({ companyname, shortintroduction, type, size, imageType,imageName,imageData}).then(company => company.id).catch(err => console.log(err));
        const contactsArr = await contacts.map(co => {
            return KeyContact.create({
                name: co.name,
                designation: co.designation,
                phone: co.phone,
                isactive: co.isactive,
                email: co.email,
                companyId: comId
            }).catch(err => console.log(err))});
        Promise.all(contactsArr).then(resp => {
           return res.status(201),json({resp,contactsArr})
        })
    }
    catch (err) {
        console.log(err)
        return res.status(500).json(err)
    }
})

app.get('/companys', async (req, res) => {
    try {
        const companys = await Company.findAll(
            {where : {is_active : true}, include:'contacts'}
        )
        res.json(companys)
    }catch (err) {
        console.log(err)
        return res.status(500).json({ error: 'Something went wrong'})
    }
})

app.get('/companys/:uuid', async (req, res) => {
    const uuid = req.params.uuid
    try {
        const company = await Company.findOne({ 
            where: { uuid, is_active : true},
            include:'contacts'
         })
        res.json(company)
    }catch (err) {
        console.log(err)
        return res.status(500).json({ error: 'Something went wrong'})
    }
})
app.delete('/companys/:uuid', async (req, res) => {
    const uuid = req.params.uuid
    try {
        const company = await Company.findOne({where: { uuid} })
        await company.destroy()
        res.json({message:'Company deleted'})
    }catch (err) {
        console.log(err)
        return res.status(500).json({ error: 'Something went wrong'})
    }
})
//update company
app.put('/companys/:uuid', async (req, res) => {
    const uuid = req.params.uuid
    const {companyname,shortintroduction,type,size} = req.body
    try {
        const company = await Company.findOne({  where: { uuid}})
        company.companyname = companyname
        company.shortintroduction = shortintroduction 
        company.type = type
        company.size = size

        await company.save()
        res.json(company)
    }catch (err) {
        console.log(err)
        return res.status(500).json({ error: 'Something went wrong'})
    }
})



app.post('/contacts', async (req, res) => {
     const {companyUuid,name,designation,phone,email} = req.body
    try {
        const company = await Company.findOne({where:{uuid:companyUuid}})

        const contact = await Contact.create({name,designation,phone,email,companyId:company.id}) 
          return res.json(contact)
    }catch(err) {
        console.error(err)
        return res.status(500).json(err)
    }
})

app.get('/contacts', async (req, res) => {

   try {
       const contacts = await KeyContact.findAll({include:[Company]})
         return res.json(contacts)
   }catch(err) {
       console.error(err)
       return res.status(500).json(err)
   }
})

app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const user = await user.findOne({ where: { email } });
  
    if (user && bcrypt.compareSync(password, user.password)) {
      const accessToken = generateAccessToken(user.id);
  
      return res.status(200).json({ accessToken });
    }
    return res.status(400).send('Invalid username or password.');
})
app.post('/register', async (req, res) => {
    const {email,password,firstName,lastName} = req.body;
    
    const alreadyExistsUser = await user.findOne({where:{email}}).catch(err => {
      console.log("Error: " + err)
    });

    if (alreadyExistsUser) {
      return res.status(409).json({message: "User with email already exists"});
    }
    const newUser = new user({email, password,firstName,lastName});
    const savedUser = await newUser.save().catch(err => {
      console.log("Error: " + err);
      res.status(500).json({error: "Cannot register user at the moment!"});
    });
    if (savedUser) res.json({ message:"Recruiter created successfully"});
})

app.authenticateToken = (req, res, next) => {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
  
    if (!token) return res.sendStatus(401);
  
    jwt.verify(token, process.env.TOKEN_SECRET, (err, payload) => {
      if (err) return res.sendStatus(403);
      req.userId = payload.userId;
      next();
    });
  };
  
  function generateAccessToken(userId) {
    return jwt.sign({ userId }, process.env.TOKEN_SECRET);
  }

//looks at our models and creates database tables

    app.listen({port:5000}, async () => {
        console.log('Server listening on http://localhost:5000')
        await sequelize.authenticate()
        console.log('Database Connected!')
    })