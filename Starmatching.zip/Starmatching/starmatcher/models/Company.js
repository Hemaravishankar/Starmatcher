'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Company extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({KeyContact}) {
      // define association here
      this.hasMany(KeyContact, {foreignKey:'companyId', as:'contacts'})

    }

    toJSON() {
      return{...this.get(),id:undefined}
    }
  };
  Company.init(
    {
      uuid:{
      type:DataTypes.UUID,
      defaultValue:DataTypes.UUIDV4,
      },
    companyname:{
      type: DataTypes.STRING,
      allowNull: false,
      validate:{
        notNull:{msg:'Company must have name'},
        notEmpty:{msg:'Name must not be empty'}
      }
    },
    imageType: DataTypes.STRING,
    imageName: DataTypes.STRING,
    imageData: DataTypes.BLOB('long'),
    shortintroduction: {
      type: DataTypes.STRING,
      allowNull: false,
      validate:{
        notNull:{msg:'Company must have shortintroduction'},
        notEmpty:{msg:'shortintroduction must not be empty'}
      }
    },
    is_active : {
      type : DataTypes.BOOLEAN,
      defaultValue : true,
    },
    type: {
      type: DataTypes.STRING,
      allowNull: false,
      validate:{
        notNull:{msg:'Company must have type'},
        notEmpty:{msg:'type must not be empty'}
      }
    },
    size: {
      type: DataTypes.STRING,
      allowNull: false,
      validate:{
        notNull:{msg:'Company must have size'},
        notEmpty:{msg:'size must not be empty'}
      }
    },
  }, {
    sequelize,
    tableName:'companies',
    modelName: 'Company',
  });
  return Company;
};