const bcrypt = require('bcrypt');

module.exports = (Sequelize, sequelize) => {
  const User = sequelize.define('user', {
    id:{
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement : true,
    },
    email: {
      type: Sequelize.STRING,
      allowNull: false,
      validate: {
        isEmail: true
      },      
      unique: { 
        msg: 'Email is already exists',
      },
    },
    firstName: {
      type: Sequelize.STRING,
      allowNull: false
    },
    lastName: {
      type: Sequelize.STRING,
      allowNull: false
    },
    phoneNumber: {
      type: Sequelize.INTEGER,
      allowNull: true,
    },
    password: {
      type: Sequelize.STRING,
      allowNull: false,
      set(value) {
        this.setDataValue('password', bcrypt.hashSync(value, 10))
      }
    },
    role_code : {
      type : Sequelize.STRING,
      allowNull: false,
    },
    is_self_verified : {
      type : Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue : false,
    },
    is_onboarding : {
      type : Sequelize.BOOLEAN,
      defaultValue : true,
    },
    fully_onboarded : {
      type : Sequelize.BOOLEAN,
      defaultValue : false,
    },
    is_active : {
      type : Sequelize.BOOLEAN,
    },
    manager : {
      type: Sequelize.STRING,
    },
    isRecLead : {
      type : Sequelize.BOOLEAN,
      allowNull : false,
      defaultValue : false,
    },
    company_id : {
      type : Sequelize.INTEGER,
    },
    location : {
      type : Sequelize.STRING,
    },
    experience : {
      type : Sequelize.STRING,
    },
    skill_group : {
      type : Sequelize.INTEGER,
    },
    ctc : {
      type : Sequelize.STRING,
    },
    createdAt : {
      type : Sequelize.DATE,
    },
    updatedAt : {
      type : Sequelize.DATE,
    },
    
  }
  ); 
  User.associate = (models) => {
    User.hasMany(models.ss_company, {
        as: 'ss_company',
        foreignKey: 'user_id',
        sourceKey: 'id',
        onDelete: 'CASCADE'
    });
    User.hasMany(models.ss_company_contacts, {
        as: 'ss_company_contacts',
        foreignKey: 'user_id',
        sourceKey: 'id',
        onDelete: 'CASCADE'
    });
    User.hasOne(models.ss_job, {
        as: 'ss_job',
        foreignKey: 'user_id',
        sourceKey: 'id',
        onDelete: 'CASCADE'
    });
    User.hasMany(models.ss_job_skills, {
        as: 'ss_job_skills',
        foreignKey: 'user_id',
        sourceKey: 'id',
        onDelete: 'CASCADE'
    });
    User.hasMany(models.ss_skills_master, {
      as: 'ss_skills_master',
      foreignKey: 'user_id',
      sourceKey: 'id',
      onDelete: 'CASCADE'
  });
};
  return User;
};