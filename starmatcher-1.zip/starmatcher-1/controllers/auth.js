const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const database = require('../models/index');
const { createUser, getUser, updateUser } = require("../model/users");
const { getResetRequest, createResetRequest } = require("../model/resetRequests");
const User = database.users;

// Login
exports.login = async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ where: { email } });

  if (user && bcrypt.compareSync(password, user.password)) {
    const accessToken = generateAccessToken(user.id);

    return res.status(200).json({ accessToken });
  }
  return res.status(400).send('Invalid username or password.');
};


// Register
exports.register = async (req, res) => {
  
    const {email,password,firstName,lastName,phoneNumber} = req.body;
    
    const alreadyExistsUser = await User.findOne({where:{email}}).catch(err => {
      console.log("Error: " + err)
    });

    if (alreadyExistsUser) {
      return res.status(409).json({message: "User with email already exists"});
    }
    const newUser = new User({email, password,firstName,lastName,phoneNumber});
    const savedUser = await newUser.save().catch(err => {
      console.log("Error: " + err);
      res.status(500).json({error: "Cannot register user at the moment!"});
    });
    if (savedUser) res.json({ message:"Recruiter created successfully"});
  
};

//change password

exports.changePassword = async (req, res) => {
  const thisRequest = getResetRequest(req.body.id);
  if(thisRequest) {
    const user = getUser(thisRequest.email);
    bcrypt.hash(req.body.password, 10).then(hashed => {
      user.password = hashed;
      updateUser(user);
      res.status(204).json({message:" request has succeeded"});
  })
} else {
  res.status(404).json({error:"page not found"});
}
};

// Authenticate token middleware
exports.authenticateToken = (req, res, next) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.sendStatus(401);

  jwt.verify(token, process.env.TOKEN_SECRET, (err, payload) => {
    if (err) return res.sendStatus(403);
    req.userId = payload.userId;
    next();
  });
};

function generateAccessToken(userId) {
  // expires after half an hour (1800 seconds = 30 minutes)
  return jwt.sign({ userId }, process.env.TOKEN_SECRET, { expiresIn: 1800 });
}
