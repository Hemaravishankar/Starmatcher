const bcrypt = require('bcryptjs');

const Company = require('../models/ss_company');
const Company_Contacts = require('../models/ss_company_contacts');

const getCompanys = async (req, res, next) => {
    let companys;
    try {
        companys = await Company.find({});
    } catch (err) {
            'Fetching companys failed, please try again later.'
    }
    await res.json({companys: companys.map(company => company.toObject({getters: true}))});
};

const getCompanyById = async (req, res, next) => {
    const companyId = req.params.cid;
    let company;
    try {
        company = await Company.findByPk(companyId)
    } catch (err) {
        "Something went wrong can't get company."
    }
    if (!company) {
        "Can't find company for provided id"
    }
    res.status(200).json({
        user: user.toObject(
            {getters: true}
        )
    });
};

exports.register = async (req, res) => {
  
    const {company, short_introduction, type, size} = req.body;

    const newCompany = new Company({company, short_introduction, type, size});
    const savedUser = await newCompany.save().catch(err => {
      console.log("Error: " + err);
      res.status(500).json({error: "Cannot register user at the moment!"});
    });
    if (savedUser) res.json({ message:"Company created successfully"});
  
};

exports.getCompanys = getCompanys;
exports.register = register;
exports.getCompanyById = getCompanyById;