const bcrypt = require('bcryptjs');

const Company_Contacts = require('../models/ss_company_contacts');



exports.register = async (req, res) => {
  
    const {company, short_introduction, type, size} = req.body;

    const newCompany = new Company_Contacts({company, short_introduction, type, size});
    const savedUser = await newCompany.save().catch(err => {
      console.log("Error: " + err);
      res.status(500).json({error: "Cannot register user at the moment!"});
    });
    if (savedUser) res.json({ message:"Company created successfully"});
  
};

exports.register = register;