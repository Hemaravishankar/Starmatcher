require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const helmet = require("helmet");



const database = require('./models');

const authRouter = require('./routes/auth');
const companyRouter = require('./routes/comapny');
const companyContactsRouter = require('./routes/companyContacts');

const authController = require('./controllers/auth');

// General
const app = express();
app.use(helmet());

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());



// Routes
app.use('/api/v2', authRouter);
app.use('/Company', companyRouter);
app.use('/CompanyContact', companyContactsRouter);

// Drop and re-sync database
database.sequelize.sync()
  .then(() => {
    console.log('Drop and re-sync database.');
  }).then(() => {
    app.listen(process.env.PORT || 2020, () => {
        console.log(`localhost : ${process.env.PORT}`);
    });
})
.catch(err => {
    console.log(err);
});
