module.exports = (Sequelize, sequelize) => {
  const Company_Contacts = sequelize.define('Company_Contacts', {
    id:{
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement : true,
    },
    email: {
      type: Sequelize.STRING,
       
      validate: {
        isEmail: true
      },      
      unique: { 
        msg: 'Email is already exists',
      },
    },
    contact_name: {
      type: Sequelize.STRING,
      allowNull: false
    },
    designation : {
      type: Sequelize.STRING,
      allowNull: false
    },
    phoneNumber: {
      type: Sequelize.STRING,
      allowNull: true,
    },
    is_active : {
      type : Sequelize.BOOLEAN,
    },
    status : {
      type: Sequelize.STRING,
    },
    company_id : {
      type : Sequelize.INTEGER,
      allowNull : false
    },
    createdAt : {
      type : Sequelize.DATE,
    },
    updatedAt : {
      type : Sequelize.DATE,
    },
    
  }
  ); 
  return Company_Contacts;
};