module.exports = (Sequelize, sequelize) => {
    const Company = sequelize.define('Company', {
            id: {
                type: Sequelize.INTEGER,
                primaryKey: true,
                autoIncrement: true
            },
            company: {
                type: Sequelize.STRING,
                allowNull: false
            },
            short_introduction: {
                type: Sequelize.TEXT,
                allowNull: false
            },
            type: {
                type: Sequelize.STRING,
                allowNull: false
            },
            size: {
                type: Sequelize.STRING,
                allowNull: false
            },
            is_active: {
                type: Sequelize.BOOLEAN,
                allowNull: false
            },
            image: {
                type: Sequelize.STRING,
                allowNull: false
            },
            role: {
                type: Sequelize.STRING,
            },
            createdAt : {
                type : Sequelize.DATE,
              },
              updatedAt : {
                type : Sequelize.DATE,
              },
         
        }, 
    );
    Company.hasMany(models.ss_company_contacts, {
        as: 'Company_contacts',
        foreignKey: 'Company_id',
        sourceKey: 'id',
        onDelete: 'CASCADE'
    });
    return Company;
}
