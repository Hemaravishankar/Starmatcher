const express = require('express');
const router = express.Router();

const CompanyController = require('../controllers/company');


router.get('/', CompanyController.getCompanys);

router.get('/:cid', CompanyController.getCompanyById);

router.post('/register', CompanyController.register)

module.exports = router;
