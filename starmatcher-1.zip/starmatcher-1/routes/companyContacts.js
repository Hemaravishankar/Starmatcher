const express = require('express');
const router = express.Router();

const CompanyContactController = require('../controllers/companyContacts');


router.post('/register', CompanyContactController.register)

module.exports = router;